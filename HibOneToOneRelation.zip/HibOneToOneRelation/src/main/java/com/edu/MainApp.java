package com.edu;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

public class MainApp {

	public static void main(String[] args) {
		//Laptop 
				Laptop lob=new Laptop();
				lob.setLid(2);
				lob.setLname("Samsung");
						
				Student sob=new Student();
				sob.setSid(12);
				sob.setSname("swetha");
				sob.setLp(lob);
				
				Configuration con=new Configuration().configure().addAnnotatedClass(Laptop.class).addAnnotatedClass(Student.class);
				ServiceRegistry reg = new ServiceRegistryBuilder().applySettings(con.getProperties()).buildServiceRegistry();
				
				//SessionFactory sf = con.buildSessionFactory(); //deprecated
				SessionFactory sf = con.buildSessionFactory(reg); //not deprecated
				Session session = sf.openSession();
				Transaction tx=session.beginTransaction();
				session.save(lob);
				session.save(sob);
				tx.commit();
			}

}
